﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebA.Migrations
{
    public partial class InitialeCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    Username = table.Column<string>(nullable: true),
                    PasswordHash = table.Column<byte[]>(nullable: true),
                    PasswordSalt = table.Column<byte[]>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AddClients",
                columns: table => new
                {
                    IdSynthese = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Date = table.Column<DateTime>(nullable: false),
                    MACD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD06 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MACI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI06 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    NomControlA = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MACIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MOCD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    NomControlO = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MOCI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    NomControlC = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AddClients", x => x.IdSynthese);
                    table.ForeignKey(
                        name: "FK_AddClients_Users_Id",
                        column: x => x.Id,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProcessITs",
                columns: table => new
                {
                    IdSynthese = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Date = table.Column<DateTime>(nullable: false),
                    MACD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACD06 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MACI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MACI06 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    NomControlA = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MACIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MOCD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    NomControlO = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MOCI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MOCIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    NomControlC = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCIN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCDN = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    MCCD01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCD05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI01 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI02 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI03 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI04 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    MCCI05 = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Id = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcessITs", x => x.IdSynthese);
                    table.ForeignKey(
                        name: "FK_ProcessITs_Users_Id",
                        column: x => x.Id,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AddClients_Id",
                table: "AddClients",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessITs_Id",
                table: "ProcessITs",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AddClients");

            migrationBuilder.DropTable(
                name: "ProcessITs");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
