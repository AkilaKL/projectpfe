using System;
using System.Collections.Generic;
using System.Linq;
using WebA.Entities;
using WebApi.Dtos;
using WebApi.Entities;
using WebApi.Helpers;

namespace WebApi.Services
{
    public interface IProcessITService
    {
        
        IEnumerable<ProcessIT> GetAll();
        ProcessIT GetById(int IdSynthese);
        ProcessIT Create(ProcessIT processIT);
        void Update(ProcessIT processIT);
        void Delete(int IdSynthese);
        
    }

    public class ProcessITService : IProcessITService
    {
        private DataContext _context;

        public ProcessITService(DataContext context)
        {
            _context = context;
        }

        

        public IEnumerable<ProcessIT> GetAll()
        {
            return _context.ProcessITs;
        }

        public ProcessIT GetById(int IdSynthese)
        {
            return _context.ProcessITs.Find(IdSynthese);
        }

        public ProcessIT Create(ProcessIT processIT)
        {
            

            if (_context.ProcessITs.Any(x => x.IdSynthese == processIT.IdSynthese))
                throw new AppException("IdSynthese \"" + processIT.IdSynthese + "\" is already taken");

           

            _context.ProcessITs.Add(processIT);
            _context.SaveChanges();

            return processIT;
        }

        public void Update(ProcessIT processitParam)
        {
            var processIT = _context.ProcessITs.Find(processitParam.IdSynthese);

            if (processIT == null)
                throw new AppException("processIT not found");

            if (processitParam.IdSynthese !=processIT.IdSynthese)
            {
                // username has changed so check if the new username is already taken
                if (_context.ProcessITs.Any(x => x.IdSynthese == processitParam.IdSynthese))
                    throw new AppException(processitParam.IdSynthese+ " is already taken");
            }

            // update user properties
            processIT.MACD01 = processitParam.MACD01;
            processIT.MACD02 = processitParam.MACD02;
            processIT.MACD03 = processitParam.MACD03;
            processIT.MACD04 = processitParam.MACD04;
            processIT.MACD05 = processitParam.MACD05;
            processIT.MACD06 = processitParam.MACD06;
            processIT.MACI01 = processitParam.MACI01;
            processIT.MACI02 = processitParam.MACI02;
            processIT.MACI03 = processitParam.MACI03;
            processIT.MACI04 = processitParam.MACI04;
            processIT.MACI05 = processitParam.MACI05;
            processIT.MACI06 = processitParam.MACI06;
            processIT.MCCD01 = processitParam.MCCD01;
            processIT.MCCD02 = processitParam.MCCD02;
            processIT.MCCD03 = processitParam.MCCD03;
            processIT.MCCD04 = processitParam.MCCD04;
            processIT.MCCD05 = processitParam.MCCD05;
            processIT.MCCI01 = processitParam.MCCI01;
            processIT.MCCI02 = processitParam.MCCI02;
            processIT.MCCI03 = processitParam.MCCI03;
            processIT.MCCI04 = processitParam.MCCI04;
            processIT.MCCI05 = processitParam.MCCI05;
            processIT.MOCD01 = processitParam.MOCD01;
            processIT.MOCD02 = processitParam.MOCD02;
            processIT.MOCD03 = processitParam.MOCD03;
            processIT.MOCI01 = processitParam.MOCI01;
            processIT.MOCI02 = processitParam.MOCI02;
            processIT.MOCI03 = processitParam.MOCI03;
           

            

            _context.ProcessITs.Update(processIT);
            _context.SaveChanges();
        }

        public void Delete(int IdSynthese)
        {
            var processIT = _context.ProcessITs.Find(IdSynthese);
            if (processIT != null)
            {
                _context.ProcessITs.Remove(processIT);
                _context.SaveChanges();
            }
        }

        

     
    }
}