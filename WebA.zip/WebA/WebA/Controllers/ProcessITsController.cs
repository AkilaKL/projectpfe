﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using WebApi.Helpers;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Authorization;
using WebApi.Services;
using WebApi.Dtos;
using WebA.Entities;

namespace WebApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ProcessITsController : ControllerBase
    {
        private IProcessITService _processITService;
        private IMapper _mapper;
        private readonly AppSettings _appSettings;

        public ProcessITsController(
            IProcessITService processITService,
            IMapper mapper,
            IOptions<AppSettings> appSettings)
        {
            _processITService = processITService;
            _mapper = mapper;
            _appSettings = appSettings.Value;
        }

        

        
        [HttpPost("Post")]
        public IActionResult Post([FromBody]ProcessITDto processITDto)
        {
            // map dto to entity
            var processIT = _mapper.Map<ProcessIT>(processITDto);

            try 
            {
                // save 
                _processITService.Create(processIT);
                return Ok();
            } 
            catch(AppException ex)
            {
                // return error message if there was an exception
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var processITs =  _processITService.GetAll();
            var processITDtos = _mapper.Map<IList<ProcessITDto>>(processITs);
            return Ok(processITDtos);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int IdSynthese)
        {
            var processIT =  _processITService.GetById(IdSynthese);
            var processITDto = _mapper.Map<ProcessITDto>(processIT);
            return Ok(processITDto);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int IdSynthese, [FromBody]ProcessITDto processITDto)
        {
            // map dto to entity and set id
            var processIT = _mapper.Map<ProcessIT>(processITDto);
            processIT.IdSynthese = IdSynthese;

            try 
            {
                // save 
                _processITService.Update(processIT);
                return Ok();
            } 
            catch(AppException ex)
            {
                // return error message if there was an exception
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int IdSynthese)
        {
            _processITService.Delete(IdSynthese);
            return Ok();
        }
    }
}
