﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebA.modells;
using WebApi.Helpers;

namespace WebA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddClientsController : ControllerBase
    {
        private readonly DataContext _context;

        public AddClientsController(DataContext context)
        {
            _context = context;
        }

        // GET: api/AddClients
        [HttpGet]
        public IEnumerable<AddClient> GetAddClients()
        {
            return _context.AddClients;
        }

        // GET: api/AddClients/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetAddClient([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var addClient = await _context.AddClients.FindAsync(id);

            if (addClient == null)
            {
                return NotFound();
            }

            return Ok(addClient);
        }

        // PUT: api/AddClients/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAddClient([FromRoute] int id, [FromBody] AddClient addClient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != addClient.IdSynthese)
            {
                return BadRequest();
            }

            _context.Entry(addClient).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AddClientExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AddClients
        [HttpPost]
        public async Task<IActionResult> PostAddClient([FromBody] AddClient addClient)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.AddClients.Add(addClient);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAddClient", new { id = addClient.IdSynthese }, addClient);
        }

        // DELETE: api/AddClients/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAddClient([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var addClient = await _context.AddClients.FindAsync(id);
            if (addClient == null)
            {
                return NotFound();
            }

            _context.AddClients.Remove(addClient);
            await _context.SaveChangesAsync();

            return Ok(addClient);
        }

        private bool AddClientExists(int id)
        {
            return _context.AddClients.Any(e => e.IdSynthese == id);
        }
    }
}