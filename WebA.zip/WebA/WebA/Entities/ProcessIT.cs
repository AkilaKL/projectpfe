﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Entities;

namespace WebA.Entities
{
    public class ProcessIT
    {
        [Key]
        [Required]
        public int IdSynthese { get; set; }
        [Required]
        public DateTime Date { get; set; }


        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD03 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD04 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD05 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACD06 { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string MACDN { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI03 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI04 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI05 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MACI06 { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string NomControlA { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string MACIN { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCD01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCD02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCD03 { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string MOCDN { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string NomControlO { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCI01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCI02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MOCI03 { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string MOCIN { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string NomControlC { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string MCCIN { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string MCCDN { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCD01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCD02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCD03 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCD04 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCD05 { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCI01 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCI02 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCI03 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCI04 { get; set; }
        [Required]
        [Column(TypeName = "nvarchar(100)")]
        public string MCCI05 { get; set; }

        public int Id { get; set; }
        [ForeignKey("Id")]
        public User User { get; set; }
    }
}
