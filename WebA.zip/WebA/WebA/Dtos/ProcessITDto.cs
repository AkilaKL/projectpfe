using System;
using WebApi.Entities;

namespace WebApi.Dtos
{
    public class ProcessITDto
    {
        public int IdSynthese { get; set; }
        public DateTime Date { get; set; }
        public string MACD01 { get; set; }
        public string MACD02 { get; set; }
        public string MACD03 { get; set; }
        public string MACD04 { get; set; }
        public string MACD05 { get; set; }
        public string MACD06 { get; set; }
        public string MACDN { get; set; }
        public string MACI01 { get; set; }
        public string MACI02 { get; set; }
        public string MACI03 { get; set; }
        public string MACI04 { get; set; }
        public string MACI05 { get; set; }
        public string MACI06 { get; set; }
        public string MACIN { get; set; }
        public string NomControlA { get; set; }
        public string MOCD01 { get; set; }
        public string MOCD02 { get; set; }
        public string MOCD03 { get; set; }
        public string MOCDN { get; set; }
        public string NomControlO { get; set; }
        public string MOCI01 { get; set; }
        public string MOCI02 { get; set; }
        public string MOCI03 { get; set; }
        public string MOCIN { get; set; }
        public string NomControlC { get; set; }
        public string MCCIN { get; set; }
        public string MCCDN { get; set; }
        public string MCCD01 { get; set; }
        public string MCCD02 { get; set; }
        public string MCCD03 { get; set; }
        public string MCCD04 { get; set; }
        public string MCCD05 { get; set; }
        public string MCCI01 { get; set; }
        public string MCCI02 { get; set; }
        public string MCCI03 { get; set; }
        public string MCCI04 { get; set; }
        public string MCCI05 { get; set; }
        public User User { get; set; }
    }
}